export interface Payment {
    admitDate: string;
    cardNumber: string;
    cvv: number;
    expYear: string;
    nameOnCard: string;
    paymentDate: string;
    paymentId: number;
    paymentStatus: string;
    prescriptionId: string;
    roomId: number;
    totalPayment: string;
    upi: string;
}